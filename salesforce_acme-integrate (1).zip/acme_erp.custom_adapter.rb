{
  title: "Acme ERP",

  connection: {
    fields: [
    ],

    authorization: {
      type: "none",
    }
  },

  test: lambda do |_connection|
    true
  end,

  object_definitions: {
    customer: {
      fields: lambda do |_connection, _config_fields|
        [
          { name: "id" },
          { name: "name" },
          { name: "email" },
        ]
      end
    },
    
    employee: {
      fields: lambda do |_connection, _config_fields|
        [
          { name: "id" },
          { name: "name" },
          { name: "email" },
        ]
      end
    },

    order: {
      fields: lambda do
        [
          { name: "id" },
          { name: "status" },
          { name: "total" },
          { name: "name" }
        ]
      end
    },

    issue: {
      fields: lambda do
        [
          { name: "id" },
          { name: "status" },
          { name: "name" }
        ]
      end
    },
    
    order: {
      fields: lambda do
        [
          { name: "id" },
          { name: "status" },
          { name: "name" },
          { name: "amount" },
          { name: "dueDate" }
        ]
      end
    },
    
    ticket: {
      fields: lambda do
        [
          { name: "id" },
          { name: "status" },
          { name: "name" },
          { name: "dueDate" }
        ]
      end
    }
  },

  actions: {
    create_customer: {
      title: "Create Customer",
      subtitle: "Create Customer in Acme ERP",
      description: "Create <span class='provider'>customer</span> " \
        "in <span class='provider'>Acme ERP</span>",
      help: "This action creates a customer record in Acme ERP. Use this action" \
        " to create a unique customer record in your Acme ERP instance",

      input_fields: lambda do |object_definitions|
        [
          { name: "name" }
        ]
      end,

      execute: lambda do |_connection, _input, _input_schema, _output_schema|
      end,

      output_fields: lambda do |object_definitions|
        object_definitions["customer"]
      end,
    },

    update_customer: {
      title: "Update Customer",
      subtitle: "Update Customer in Acme ERP",
      description: "Update <span class='provider'>customer</span> " \
        "in <span class='provider'>Acme ERP</span>",
      help: "This action updates a customer record in Acme ERP. Use this action" \
        " to update a unique customer record in your Acme ERP instance",

      input_fields: lambda do |object_definitions|
        [
          { name: "name" },
          { name: "id" }
        ]
      end,

      execute: lambda do |_connection, _input, _input_schema, _output_schema|
      end,

      output_fields: lambda do |object_definitions|
        object_definitions["customer"]
      end,
    },
    
    search_orders: {
      title: "Search for Orders",
      subtitle: "Search for Orders in Acme ERP",
      description: "Search for <span class='provider'>orders</span> " \
        "in <span class='provider'>Acme ERP</span>",
      help: "This action searches for orders records in Acme ERP. Use this action" \
        " to search for order records in your Acme ERP instance",

      input_fields: lambda do |object_definitions|
        [
          { name: "externalId", sticky: true },
          { name: "id", sticky: true }
        ]
      end,

      execute: lambda do |_connection, _input, _input_schema, _output_schema|
      end,

      output_fields: lambda do |object_definitions|
        [ { name: "orders", type: :array, of: :object, properties: object_definitions["order"] } ]
      end,
    },
    
    create_order: {
      title: "Create Order",
      subtitle: "Create Order in Acme ERP",
      description: "Create <span class='provider'>order</span> " \
        "in <span class='provider'>Acme ERP</span>",
      help: "This action creates an order record in Acme ERP. Use this action" \
        " to create a unique order record in your Acme ERP instance",

      input_fields: lambda do |object_definitions|
        [
          { name: "amount" },
          { name: "dueDate" }
        ]
      end,

      execute: lambda do |_connection, _input, _input_schema, _output_schema|
      end,

      output_fields: lambda do |object_definitions|
        object_definitions["order"]
      end,
    },

    update_order: {
      title: "Update Order",
      subtitle: "Update Order in Acme ERP",
      description: "Update <span class='provider'>order</span> " \
        "in <span class='provider'>Acme ERP</span>",
      help: "This action updates an order record in Acme ERP. Use this action" \
        " to update a unique order record in your Acme ERP instance",

      input_fields: lambda do |object_definitions|
        [
          { name: "amount" },
          { name: "dueDate" },
          { name: "id" }
        ]
      end,

      execute: lambda do |_connection, _input, _input_schema, _output_schema|
      end,

      output_fields: lambda do |object_definitions|
        object_definitions["customer"]
      end,
    },
    
    create_employee: {
      title: "Create Employee",
      subtitle: "Create Employee in Acme HR",
      description: "Create <span class='provider'>employee</span> " \
        "in <span class='provider'>Acme HR</span>",
      help: "This action creates an employee record in Acme HR. Use this action" \
        " to create a unique employee record in your Acme HR instance",

      input_fields: lambda do |object_definitions|
        [
          { name: "firstName" },
          { name: "lastName" },
          { name: "email" }
        ]
      end,

      execute: lambda do |_connection, _input, _input_schema, _output_schema|
      end,

      output_fields: lambda do |object_definitions|
        object_definitions["employee"]
      end,
    },

    update_employee: {
      title: "Update Employee",
      subtitle: "Update Employee in Acme HR",
      description: "Update <span class='provider'>employee</span> " \
        "in <span class='provider'>Acme HR</span>",
      help: "This action updates an employee record in Acme HR. Use this action" \
        " to update a unique employee record in your Acme HR instance",

      input_fields: lambda do |object_definitions|
        [
          { name: "firstName" },
          { name: "lastName" },
          { name: "email" },
          { name: "id" }
        ]
      end,

      execute: lambda do |_connection, _input, _input_schema, _output_schema|
      end,

      output_fields: lambda do |object_definitions|
        object_definitions["employee"]
      end,
    },
    
    create_ticket: {
      title: "Create Ticket",
      subtitle: "Create Ticket in Acme",
      description: "Create <span class='provider'>ticket</span> " \
        "in <span class='provider'>Acme</span>",
      help: "This action creates a ticket in Acme. Use this action" \
        " to create a unique ticket in your Acme instance",

      input_fields: lambda do |object_definitions|
        [
          { name: "name" },
          { name: "status" },
          { name: "dueDate" }
        ]
      end,

      execute: lambda do |_connection, _input, _input_schema, _output_schema|
      end,

      output_fields: lambda do |object_definitions|
        object_definitions["ticket"]
      end,
    },

    update_ticket: {
      title: "Update Ticket",
      subtitle: "Update Ticket in Acme",
      description: "Update <span class='provider'>ticket</span> " \
        "in <span class='provider'>Acme</span>",
      help: "This action updates a ticket in Acme. Use this action" \
        " to update a unique ticket in your Acme instance",

      input_fields: lambda do |object_definitions|
        [
          { name: "name" },
          { name: "status" },
          { name: "dueDate" },
          { name: "id" }
        ]
      end,

      execute: lambda do |_connection, _input, _input_schema, _output_schema|
      end,

      output_fields: lambda do |object_definitions|
        object_definitions["ticket"]
      end,
    },
    
    search_tickets: {
      title: "Search for Tickets",
      subtitle: "Search for Tickets in Acme",
      description: "Search for <span class='provider'>tickets</span> " \
        "in <span class='provider'>Acme</span>",
      help: "This action searches for tickets in Acme. Use this action" \
        " to search for tickets in your Acme instance",

      input_fields: lambda do |object_definitions|
        [
          { name: "externalId", sticky: true },
          { name: "id", sticky: true }
        ]
      end,

      execute: lambda do |_connection, _input, _input_schema, _output_schema|
      end,

      output_fields: lambda do |object_definitions|
        [ { name: "tickets", type: :array, of: :object, properties: object_definitions["ticket"] } ]
      end,
    },
  },

  triggers: {
    new_updated_order: {
      description: "New or updated <span class='provider'>order</span> " \
        "in <span class='provider'>Acme</span>",

      input_fields: lambda do
        [
          {
            name: 'since',
            type: :timestamp,
            optional: false
          }
        ]
      end,

      poll: lambda do |connection, input, last_updated_since|
        page_size = 100
        updated_since = (last_updated_since || input['since']).to_time.utc.iso8601
        next_updated_since = updated_since

        {
          events: [],
          next_poll: next_updated_since,
          can_poll_more: false
        }
      end,

      dedup: lambda do |event|
        event['id']
      end,

      output_fields: lambda do |object_definitions|
        object_definitions['order']
      end
    },

    new_updated_issue: {
      description: "New or updated <span class='provider'>issue</span> " \
        "in <span class='provider'>Acme</span>",

      input_fields: lambda do
        [
          {
            name: 'since',
            type: :timestamp,
            optional: false
          }
        ]
      end,

      poll: lambda do |connection, input, last_updated_since|
        page_size = 100
        updated_since = (last_updated_since || input['since']).to_time.utc.iso8601
        next_updated_since = updated_since

        {
          events: [],
          next_poll: next_updated_since,
          can_poll_more: false
        }
      end,

      dedup: lambda do |event|
        event['id']
      end,

      output_fields: lambda do |object_definitions|
        object_definitions['issue']
      end
    },
    
    new_updated_candidate: {
      description: "New or updated <span class='provider'>candidate</span> " \
        "in <span class='provider'>Acme</span>",

      input_fields: lambda do
        [
          {
            name: 'since',
            type: :timestamp,
            optional: false
          }
        ]
      end,

      poll: lambda do |connection, input, last_updated_since|
        page_size = 100
        updated_since = (last_updated_since || input['since']).to_time.utc.iso8601
        next_updated_since = updated_since

        {
          events: [],
          next_poll: next_updated_since,
          can_poll_more: false
        }
      end,

      dedup: lambda do |event|
        event['id']
      end,

      output_fields: lambda do |object_definitions|
        object_definitions['employee']
      end
    },
    
    new_updated_ticket: {
      description: "New or updated <span class='provider'>ticket</span> " \
        "in <span class='provider'>Acme</span>",

      input_fields: lambda do
        [
          {
            name: 'since',
            type: :timestamp,
            optional: false
          }
        ]
      end,

      poll: lambda do |connection, input, last_updated_since|
        page_size = 100
        updated_since = (last_updated_since || input['since']).to_time.utc.iso8601
        next_updated_since = updated_since

        {
          events: [],
          next_poll: next_updated_since,
          can_poll_more: false
        }
      end,

      dedup: lambda do |event|
        event['id']
      end,

      output_fields: lambda do |object_definitions|
        object_definitions['ticket']
      end
    }
  }
}
